import tkinter as tk
import random

# --- Global Logic Variables ---
rocks = []
game_running = True
won = False
score = 0
fall_speed = 7

def start_game():
    global rocks, game_running, score, fall_speed, won
    canvas.delete("all")
    rocks = []
    game_running = True
    won = False
    score = 0
    fall_speed = 7
    canvas.config(bg="#87CEEB")
    
    global player, score_display
    player = canvas.create_rectangle(180, 520, 220, 560, fill="white", outline="black")
    score_display = canvas.create_text(50, 20, text="Score: 0", font=("Arial", 12, "bold"), fill="black")
    
    spawn_rock()
    update_game()

# --- THE POPUPS ---

def show_victory_popup():
    """The Third Window Layer: Victory"""
    vic_win = tk.Toplevel(root)
    vic_win.title("Winner!")
    vic_win.geometry("300x150+450+300")
    vic_win.configure(bg="black")
    vic_win.attributes("-topmost", True) # Keeps it in front of the game
    
    tk.Label(vic_win, text="YOU WON!", font=("Arial", 24, "bold"), fg="gold", bg="black").pack(pady=10)
    tk.Label(vic_win, text="You reached Deep Space!", fg="white", bg="black").pack()
    tk.Button(vic_win, text="CONTINUE FALLING", command=vic_win.destroy, bg="#444", fg="white").pack(pady=10)

def show_game_over_popup():
    """The Second Window Layer: Game Over"""
    global game_running
    game_running = False
    
    go_win = tk.Toplevel(root)
    go_win.title("Crashed")
    go_win.geometry("300x200+450+300")
    go_win.configure(bg="#f0f0f0")
    go_win.attributes("-topmost", True)
    
    # Force closing this popup to exit the whole game
    go_win.protocol("WM_DELETE_WINDOW", root.destroy)

    tk.Label(go_win, text="GAME OVER", font=("Arial", 20, "bold"), fg="red").pack(pady=10)
    tk.Label(go_win, text=f"Final Score: {score}", font=("Arial", 12)).pack()

    # Buttons to control the main game from the popup
    tk.Button(go_win, text="RETRY", width=15, bg="green", fg="white", 
              command=lambda: [go_win.destroy(), start_game()]).pack(pady=5)
    tk.Button(go_win, text="QUIT", width=15, bg="black", fg="white", 
              command=root.destroy).pack(pady=5)

# --- CORE ENGINE ---

def spawn_rock():
    if not game_running: return
    x_pos = random.randint(0, 370)
    roll = random.random()
    if roll < 0.05:
        r = canvas.create_rectangle(x_pos, -30, x_pos+30, 0, fill="green", tags="emergency")
    elif roll < 0.35:
        r = canvas.create_rectangle(x_pos, -30, x_pos+30, 0, fill="red", tags="special")
    else:
        r = canvas.create_rectangle(x_pos, -30, x_pos+30, 0, fill="gray", tags="normal")
    rocks.append(r)
    root.after(max(150, 1000 - (score * 2)), spawn_rock)

def update_game():
    global game_running, score, fall_speed, won
    if not game_running: return
    
    # Victory Check
    if score >= 500 and not won:
        won = True
        canvas.config(bg="black")
        canvas.itemconfig(score_display, fill="white")
        show_victory_popup()

    p_pos = canvas.coords(player)
    for r in rocks[:]:
        canvas.move(r, 0, fall_speed)
        r_pos = canvas.coords(r)
        
        # Collision
        if (p_pos[0] < r_pos[2] and p_pos[2] > r_pos[0] and p_pos[1] < r_pos[3] and p_pos[3] > r_pos[1]):
            tag = canvas.gettags(r)[0]
            if tag == "red":
                fall_speed = 30; canvas.itemconfig(player, fill="orange")
                root.after(2000, lambda: reset_speed())
                canvas.delete(r); rocks.remove(r)
            elif tag == "green":
                fall_speed = 2; score += 50; canvas.itemconfig(player, fill="lime")
                root.after(3000, lambda: reset_speed())
                canvas.delete(r); rocks.remove(r)
            else:
                show_game_over_popup()
                return
        elif r_pos[1] > 600:
            canvas.delete(r); rocks.remove(r)
            score += 1
            canvas.itemconfig(score_display, text=f"Score: {score}")
    root.after(20, update_game)

def reset_speed():
    global fall_speed
    if game_running: fall_speed = 7; canvas.itemconfig(player, fill="white")

# --- ROOT SETUP ---
root = tk.Tk()
root.title("FITS: Popup Edition")
canvas = tk.Canvas(root, width=400, height=600, bg="#87CEEB", highlightthickness=0)
canvas.pack()

# Controls
def handle_input(event):
    if not game_running: return
    if hasattr(event, 'x'): # Mouse
        canvas.coords(player, event.x-20, 520, event.x+20, 560)
    else: # Keyboard
        p, k = canvas.coords(player), event.keysym.lower()
        if k in ['a', 'left'] and p[0] > 0: canvas.move(player, -25, 0)
        if k in ['d', 'right'] and p[2] < 400: canvas.move(player, 25, 0)

canvas.bind("<Motion>", handle_input)
root.bind("<Key>", handle_input)

start_game()
root.mainloop()
