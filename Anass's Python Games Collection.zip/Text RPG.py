def start_game():
    # 1. Setup the Game State
    inventory = []
    current_room = "Hallway"
    
    # 2. Define the Map (The Dictionary)
    rooms = {
        "Hallway": {
            "desc": "You are in a dusty hallway. There is a door to the NORTH and SOUTH.",
            "north": "Kitchen",
            "south": "Bedroom"
        },
        "Kitchen": {
            "desc": "It smells like old pizza here. There is a SHINY KEY on the table. Door to the SOUTH.",
            "item": "key",
            "south": "Hallway"
        },
        "Bedroom": {
            "desc": "A messy room. There is a locked MASSIVE CHEST here. Door to the NORTH.",
            "north": "Hallway"
        }
    }

    print("--- WELCOME TO THE PYTHON DUNGEON ---")
    print("Commands: go [north/south/east/west], get [item], inventory, quit")

    # 3. The Game Loop
    while True:
        print("\n" + "-"*30)
        print(rooms[current_room]["desc"])
        
        # Get user input
        choice = input("> ").lower().split()

        if not choice: continue
        
        action = choice[0]

        # --- MOVEMENT ---
        if action == "go":
            direction = choice[1]
            if direction in rooms[current_room]:
                current_room = rooms[current_room][direction]
            else:
                print("You can't go that way!")

        # --- GET ITEMS ---
        elif action == "get":
            item_target = choice[1]
            if "item" in rooms[current_room] and item_target == rooms[current_room]["item"]:
                print(f"You picked up the {item_target}!")
                inventory.append(item_target)
                del rooms[current_room]["item"] # Remove item from room
            else:
                print("I don't see that here.")

        # --- SPECIAL ACTION: OPEN CHEST ---
        elif action == "open" and current_room == "Bedroom":
            if "key" in inventory:
                print("YOU DID IT! You opened the chest and found... A NEW PC! YOU WIN!")
                break
            else:
                print("The chest is locked. You need a key.")

        elif action == "inventory":
            print(f"Items: {inventory}")

        elif action == "quit":
            print("Thanks for playing!")
            break
        
        else:
            print("I don't understand that command.")

if __name__ == "__main__":
    start_game()
