import tkinter as tk
from tkinter import messagebox

class PomodoroTimer:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Pomodoro")
        self.root.geometry("350x250")
        self.root.configure(bg="#2c3e50") # Dark slate blue background

        self.seconds = 1500 # 25 minutes
        self.running = False

        # --- Display ---
        self.label = tk.Label(root, text="25:00", font=("Courier", 50, "bold"), 
                              fg="#e74c3c", bg="#2c3e50")
        self.label.pack(pady=30)

        # --- Buttons ---
        self.btn_frame = tk.Frame(root, bg="#2c3e50")
        self.btn_frame.pack()

        self.start_btn = tk.Button(self.btn_frame, text="START", command=self.toggle,
                                   width=10, bg="#27ae60", fg="white", font=("Arial", 10, "bold"))
        self.start_btn.grid(row=0, column=0, padx=5)

        self.reset_btn = tk.Button(self.btn_frame, text="RESET", command=self.reset,
                                   width=10, bg="#95a5a6", fg="white", font=("Arial", 10, "bold"))
        self.reset_btn.grid(row=0, column=1, padx=5)

        self.update_clock()

    def toggle(self):
        self.running = not self.running
        self.start_btn.config(text="PAUSE" if self.running else "START", 
                              bg="#f39c12" if self.running else "#27ae60")

    def reset(self):
        self.running = False
        self.seconds = 1500
        self.label.config(text="25:00")
        self.start_btn.config(text="START", bg="#27ae60")

    def update_clock(self):
        if self.running and self.seconds > 0:
            self.seconds -= 1
            mins, secs = divmod(self.seconds, 60)
            self.label.config(text=f"{mins:02d}:{secs:02d}")
            
            if self.seconds == 0:
                self.running = False
                messagebox.showinfo("Time's Up!", "Take a 5-minute break!")
                self.reset()
                
        self.root.after(1000, self.update_clock)

# --- START THE PROGRAM ---
if __name__ == "__main__":
    root = tk.Tk()
    app = PomodoroTimer(root)
    root.mainloop()
