import tkinter as tk
import random

class BrickBreaker:
    def __init__(self, root):
        self.root = root
        self.root.title("Brick Breaker: Restart Edition")
        
        self.canvas = tk.Canvas(root, width=600, height=400, bg="black")
        self.canvas.pack()
        
        # Create a button on the UI (not on the canvas)
        self.restart_btn = tk.Button(root, text="Restart Game", command=self.setup_game, bg="gray", fg="white")
        self.restart_btn.pack(pady=5)
        
        self.setup_game()

    def setup_game(self):
        """This function sets up (or resets) all game objects"""
        self.canvas.delete("all") # Clear everything off the screen
        
        self.game_running = True
        
        # 1. The Paddle
        self.paddle = self.canvas.create_rectangle(250, 380, 350, 390, fill="cyan")
        
        # 2. The Ball
        self.ball = self.canvas.create_oval(290, 200, 310, 220, fill="white")
        self.dx = 3
        self.dy = -3
        
        # 3. The Bricks
        self.bricks = []
        colors = ["#FF5555", "#FFB86C", "#F1FA8C", "#50FA7B"]
        for row in range(4):
            for col in range(10):
                x1 = col * 60 + 2
                y1 = row * 20 + 20
                x2 = x1 + 56
                y2 = y1 + 16
                brick = self.canvas.create_rectangle(x1, y1, x2, y2, fill=colors[row], outline="black")
                self.bricks.append(brick)
        
        # Controls
        self.root.bind("<Left>", lambda e: self.canvas.move(self.paddle, -30, 0))
        self.root.bind("<Right>", lambda e: self.canvas.move(self.paddle, 30, 0))
        self.canvas.bind("<Motion>", self.mouse_move)
        
        self.update()

    def mouse_move(self, event):
        if self.game_running:
            x = event.x
            if 50 <= x <= 550:
                self.canvas.coords(self.paddle, x-50, 380, x+50, 390)

    def update(self):
        if not self.game_running:
            return

        self.canvas.move(self.ball, self.dx, self.dy)
        pos = self.canvas.coords(self.ball)
        
        # Wall Bounces
        if pos[0] <= 0 or pos[2] >= 600:
            self.dx *= -1
        if pos[1] <= 0:
            self.dy *= -1
            
        # Paddle Bounce
        paddle_pos = self.canvas.coords(self.paddle)
        if pos[2] >= paddle_pos[0] and pos[0] <= paddle_pos[2]:
            if pos[3] >= paddle_pos[1] and pos[3] <= paddle_pos[3]:
                self.dy = -abs(self.dy)
        
        # Brick Bounces
        for brick in self.bricks[:]:
            b_pos = self.canvas.coords(brick)
            if pos[2] >= b_pos[0] and pos[0] <= b_pos[2] and pos[3] >= b_pos[1] and pos[1] <= b_pos[3]:
                self.canvas.delete(brick)
                self.bricks.remove(brick)
                self.dy *= -1
                break
        
        # Win/Loss
        if not self.bricks:
            self.canvas.create_text(300, 200, text="YOU WIN!", fill="gold", font=("Arial", 30, "bold"))
            self.game_running = False
        elif pos[3] >= 400:
            self.canvas.create_text(300, 200, text="GAME OVER", fill="white", font=("Arial", 30, "bold"))
            self.game_running = False
        else:
            self.root.after(10, self.update)

if __name__ == "__main__":
    root = tk.Tk()
    BrickBreaker(root)
    root.mainloop()
