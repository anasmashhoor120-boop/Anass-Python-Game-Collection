import tkinter as tk
import math

# Settings for Slow PCs
WIDTH, HEIGHT = 400, 300
MAP_SIZE = 8
TILE_SIZE = 50
# 1 = Wall, 0 = Empty Space
GAME_MAP = [
    [1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1],
    [1,0,1,0,0,1,0,1],
    [1,0,1,0,0,1,0,1],
    [1,0,0,0,0,0,0,1],
    [1,0,1,1,1,1,0,1],
    [1,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1],
]

px, py = 100, 100 # Player Position
pa = 0            # Player Angle

def draw_view():
    canvas.delete("all")
    # Draw Floor and Ceiling
    canvas.create_rectangle(0, HEIGHT/2, WIDTH, HEIGHT, fill="#555") # Floor
    canvas.create_rectangle(0, 0, WIDTH, HEIGHT/2, fill="#77b")     # Sky

    # Raycasting (The Magic Part)
    for r in range(60): # 60 rays for 60 degrees of vision
        ra = pa - (30 * math.pi/180) + (r * math.pi/180)
        dist = 0
        x, y = px, py
        
        # Shoot a ray until it hits a wall
        while dist < 400:
            dist += 2
            x = px + math.cos(ra) * dist
            y = py + math.sin(ra) * dist
            if GAME_MAP[int(y/TILE_SIZE)][int(x/TILE_SIZE)] == 1:
                break
        
        # Calculate wall height based on distance
        line_h = (TILE_SIZE * HEIGHT) / (dist * math.cos(ra - pa))
        color = 255 - int(dist * 0.5) # Darker walls far away
        if color < 0: color = 0
        hex_color = f'#{color:02x}{color:02x}{color:02x}'
        
        # Draw the vertical slice of the wall
        canvas.create_line(r*(WIDTH/60), HEIGHT/2 - line_h/2, 
                           r*(WIDTH/60), HEIGHT/2 + line_h/2, 
                           fill=hex_color, width=WIDTH/60 + 1)

def movement(event):
    global px, py, pa
    if event.keysym == 'Left': pa -= 0.1
    if event.keysym == 'Right': pa += 0.1
    if event.keysym == 'Up':
        px += math.cos(pa) * 5
        py += math.sin(pa) * 5
    if event.keysym == 'Down':
        px -= math.cos(pa) * 5
        py -= math.sin(pa) * 5
    draw_view()

root = tk.Tk()
root.title("MAKANY'S FIRST PERSON ENGINE")
canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="black")
canvas.pack()

draw_view()
root.bind("<KeyPress>", movement)
root.mainloop()
