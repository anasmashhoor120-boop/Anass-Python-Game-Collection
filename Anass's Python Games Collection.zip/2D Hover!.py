import tkinter as tk
import random
import winsound  # This is the music brain!

# 1. Game Settings
WIDTH, HEIGHT = 600, 450
flags_collected = 0

# 2. START THE MUSIC (Looping in the background)
# Note: This looks for a file called "music.wav" in your folder.
try:
    winsound.PlaySound("music.wav", winsound.SND_ASYNC | winsound.SND_LOOP)
except:
    print("Music file not found, but game starting anyway!")

def move_player(event):
    global flags_collected
    step = 15
    old_pos = canvas.coords(player) # Save where we were
    
    # Movement logic
    if event.keysym == 'Up': move = (0, -step)
    elif event.keysym == 'Down': move = (0, step)
    elif event.keysym == 'Left': move = (-step, 0)
    elif event.keysym == 'Right': move = (step, 0)
    else: return

    canvas.move(player, *move)
    new_pos = canvas.coords(player)

    # WALL DETECTION: If we hit a wall, move back!
    for wall in walls:
        w_pos = canvas.coords(wall)
        if (new_pos[0] < w_pos[2] and new_pos[2] > w_pos[0] and
            new_pos[1] < w_pos[3] and new_pos[3] > w_pos[1]):
            canvas.move(player, -move[0], -move[1]) # Bounce back!
            winsound.Beep(400, 50) # Make a "bonk" sound

    # FLAG DETECTION
    for f in flags[:]:
        f_pos = canvas.coords(f)
        if (new_pos[0] < f_pos[2] and new_pos[2] > f_pos[0] and
            new_pos[1] < f_pos[3] and new_pos[3] > f_pos[1]):
            canvas.delete(f)
            flags.remove(f)
            flags_collected += 1
            label_score.config(text=f"Flags: {flags_collected}/3")
            winsound.Beep(1000, 100) # Make a "ding" sound
            
            if flags_collected == 3:
                label_score.config(text="LEVEL 1 CLEAR!", fg="lime")

# 3. Setup the Maze
root = tk.Tk()
root.title("2D Hover! - Level 1")

label_score = tk.Label(root, text="Flags: 0/3", font=("Arial", 20), bg="#008080", fg="white")
label_score.pack(fill="x")

canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="#008080") # Windows 95 Teal
canvas.pack()

# Create Walls (The Maze)
walls = [
    canvas.create_rectangle(150, 0, 170, 250, fill="gray", outline="black"),
    canvas.create_rectangle(350, 150, 370, 450, fill="gray", outline="black"),
    canvas.create_rectangle(0, 300, 250, 320, fill="gray", outline="black")
]

# Create Player
player = canvas.create_rectangle(20, 20, 50, 50, fill="red", outline="white", width=2)

# Create 3 Flags
flags = []
for i in range(3):
    rx, ry = random.randint(50, 550), random.randint(50, 400)
    f = canvas.create_oval(rx, ry, rx+20, ry+20, fill="blue", outline="white")
    flags.append(f)

root.bind("<KeyPress>", move_player)
root.mainloop()
# 1. Near the top where your settings are, add:
drone_speed = 3

# 2. Add this NEW function to make the drone move on its own
def move_drone():
    # Find where the player is
    p_pos = canvas.coords(player)
    d_pos = canvas.coords(drone)
    
    # Simple AI: Move toward the player
    dx = 0
    dy = 0
    if p_pos[0] > d_pos[0]: dx = drone_speed
    elif p_pos[0] < d_pos[0]: dx = -drone_speed
    
    if p_pos[1] > d_pos[1]: dy = drone_speed
    elif p_pos[1] < d_pos[1]: dy = -drone_speed
    
    canvas.move(drone, dx, dy)
    
    # If the drone touches you, you get "bumped"
    if (p_pos[0] < d_pos[2] and p_pos[2] > d_pos[0] and
        p_pos[1] < d_pos[3] and p_pos[3] > d_pos[1]):
        canvas.move(player, dx*5, dy*5) # BUMP!
        winsound.Beep(200, 100) # Low "thud" sound

    # Tell the computer to run this function again in 50 milliseconds
    root.after(50, move_drone)

# 3. Inside your setup area (where you create the player), add:
drone = canvas.create_rectangle(500, 50, 530, 80, fill="blue", outline="black", width=2)

# 4. Right before root.mainloop(), start the drone:
move_drone()
def start_level_2():
    global current_level, flags_collected, walls, flags, drone_speed
    
    current_level = 2
    flags_collected = 0
    drone_speed = 5  # Make the drone faster for Level 2!
    
    # 1. Clear everything!
    canvas.delete("all")
    
    # 2. Draw Level 2 Walls (A different pattern)
    walls.clear()
    walls.append(canvas.create_rectangle(100, 100, 500, 120, fill="silver"))
    walls.append(canvas.create_rectangle(100, 300, 500, 320, fill="silver"))
    
    # 3. Create Player & Drone again
    global player, drone
    player = canvas.create_rectangle(20, 20, 50, 50, fill="red", outline="white")
    drone = canvas.create_rectangle(500, 350, 530, 380, fill="blue", outline="black")
    
    # 4. Create 3 New Flags
    flags.clear()
    for i in range(3):
        rx, ry = random.randint(50, 550), random.randint(50, 400)
        f = canvas.create_oval(rx, ry, rx+20, ry+20, fill="blue", outline="white")
        flags.append(f)
        
    label_score.config(text="LEVEL 2: Flags 0/3", fg="orange")
    winsound.Beep(800, 500) # Victory sound!
