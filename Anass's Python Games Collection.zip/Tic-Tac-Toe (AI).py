import tkinter as tk
from tkinter import messagebox
import random

class TicTacToeEasy:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic-Tac-Toe: AI")
        self.board = [" " for _ in range(9)]
        self.buttons = []
        
        for i in range(9):
            btn = tk.Button(root, text=" ", font=('Arial', 20, 'bold'), 
                            width=5, height=2, bg="#333", fg="white",
                            command=lambda i=i: self.player_move(i))
            btn.grid(row=i//3, column=i%3, padx=5, pady=5)
            self.buttons.append(btn)

    def player_move(self, i):
        if self.board[i] == " ":
            self.make_move(i, "X")
            if not self.check_winner("X") and " " in self.board:
                # Computer waits half a second then picks a random spot
                self.root.after(500, self.computer_move)

    def computer_move(self):
        empty_spots = [index for index, spot in enumerate(self.board) if spot == " "]
        if empty_spots:
            move = random.choice(empty_spots) # RANDOM CHANCE!
            self.make_move(move, "O")
            self.check_winner("O")

    def make_move(self, i, player):
        self.board[i] = player
        color = "#00ffff" if player == "X" else "#ffaa00"
        self.buttons[i].config(text=player, state='disabled', disabledforeground=color)

    def check_winner(self, p):
        wins = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
        for a, b, c in wins:
            if self.board[a] == self.board[b] == self.board[c] == p:
                messagebox.showinfo("Result", f"{p} Wins!")
                self.reset_board()
                return True
        if " " not in self.board:
            messagebox.showinfo("Result", "It's a Tie!")
            self.reset_board()
            return True
        return False

    def reset_board(self):
        self.board = [" " for _ in range(9)]
        for btn in self.buttons:
            btn.config(text=" ", state='normal')

if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg="black")
    TicTacToeEasy(root)
    root.mainloop()
