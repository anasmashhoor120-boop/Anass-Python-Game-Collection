import tkinter as tk
import time # Needed for millisecond tracking

class MazeGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Maze Speedrun")
        
        self.canvas = tk.Canvas(root, width=600, height=400, bg="black")
        self.canvas.pack()
        
        self.btn = tk.Button(root, text="Restart", command=self.setup_maze)
        self.btn.pack()
        
        self.setup_maze()

    def setup_maze(self):
        self.canvas.delete("all")
        self.game_over = False
        
        # Start the clock!
        self.start_time = time.time()
        
        # Walls
        self.walls = [
            self.canvas.create_rectangle(150, 0, 200, 300, fill="#333333"),
            self.canvas.create_rectangle(350, 100, 400, 400, fill="#333333")
        ]
        
        # Goal
        self.finish = self.canvas.create_rectangle(550, 0, 600, 400, fill="gold")
        
        # Player
        self.player = self.canvas.create_oval(10, 190, 30, 210, fill="cyan")
        
        # Bindings
        self.canvas.bind("<Motion>", self.mouse_move)
        self.root.bind("<Up>", lambda e: self.move_player(0, -15))
        self.root.bind("<Down>", lambda e: self.move_player(0, 15))
        self.root.bind("<Left>", lambda e: self.move_player(-15, 0))
        self.root.bind("<Right>", lambda e: self.move_player(15, 0))

    def check_collision(self):
        p = self.canvas.coords(self.player)
        hits = self.canvas.find_overlapping(p[0], p[1], p[2], p[3])
        
        for item in hits:
            if item in self.walls:
                self.game_over = True
                self.canvas.itemconfig(self.player, fill="red")
                self.root.after(500, self.setup_maze)
            elif item == self.finish:
                self.handle_win()

    def handle_win(self):
        self.game_over = True
        # Calculate the difference in time
        end_time = time.time()
        # Multiply by 1000 to get milliseconds
        total_time = int((end_time - self.start_time) * 1000)
        
        self.canvas.create_text(300, 180, text="WINNER!", fill="gold", font=("Arial", 30, "bold"))
        self.canvas.create_text(300, 230, text=f"Time: {total_time}ms", fill="white", font=("Arial", 20))

    def mouse_move(self, event):
        if not self.game_over:
            self.canvas.coords(self.player, event.x-10, event.y-10, event.x+10, event.y+10)
            self.check_collision()

    def move_player(self, dx, dy):
        if not self.game_over:
            self.canvas.move(self.player, dx, dy)
            self.check_collision()

if __name__ == "__main__":
    root = tk.Tk()
    game = MazeGame(root)
    root.mainloop()
