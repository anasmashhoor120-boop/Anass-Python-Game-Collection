import tkinter as tk
import random

class RainbowSnake:
    def __init__(self, root):
        self.root = root
        self.root.title("Rainbow Snake - Eyes Edition")
        
        self.width = 600
        self.height = 400
        self.tile_size = 20
        self.speed = 100 
        
        self.canvas = tk.Canvas(root, width=self.width, height=self.height, bg="black", highlightthickness=0)
        self.canvas.pack()
        
        self.colors = ["#ff0000", "#ff7f00", "#ffff00", "#00ff00", "#0000ff", "#8b00ff"]
        self.color_index = 0
        self.score = 0
        
        self.root.bind("<KeyPress>", self.change_direction)
        
        self.reset_game()
        self.play()

    def reset_game(self):
        self.snake = [[100, 100], [80, 100], [60, 100]]
        self.direction = "Right"
        self.score = 0
        self.running = True
        self.spawn_food()

    def spawn_food(self):
        max_x = (self.width // self.tile_size) - 1
        max_y = (self.height // self.tile_size) - 1
        self.food = [random.randint(0, max_x) * self.tile_size, 
                     random.randint(0, max_y) * self.tile_size]

    def change_direction(self, event):
        key = event.keysym
        opposites = {"Up": "Down", "Down": "Up", "Left": "Right", "Right": "Left"}
        if key in opposites and key != opposites.get(self.direction):
            self.direction = key

    def play(self):
        if self.running:
            hx, hy = self.snake[0]
            if self.direction == "Up": hy -= self.tile_size
            elif self.direction == "Down": hy += self.tile_size
            elif self.direction == "Left": hx -= self.tile_size
            elif self.direction == "Right": hx += self.tile_size
            
            new_head = [hx, hy]

            if (hx < 0 or hx >= self.width or hy < 0 or hy >= self.height or 
                new_head in self.snake):
                self.game_over()
            else:
                self.snake.insert(0, new_head)
                if new_head == self.food:
                    self.score += 10
                    self.spawn_food()
                    self.color_index = (self.color_index + 1) % len(self.colors)
                else:
                    self.snake.pop()
                
                self.draw()
                self.root.after(self.speed, self.play)

    def draw(self):
        self.canvas.delete("all")
        
        # Draw Score
        self.canvas.create_text(60, 20, text=f"SCORE: {self.score}", fill="white", font=("Courier", 14, "bold"))
        
        # Draw Gold Apple
        self.canvas.create_oval(self.food[0]+2, self.food[1]+2, 
                                self.food[0]+18, self.food[1]+18, fill="#ffd700", outline="orange")
        
        # Draw Snake
        for i, segment in enumerate(self.snake):
            color = self.colors[self.color_index]
            
            # Draw the body segment
            self.canvas.create_rectangle(segment[0], segment[1], 
                                         segment[0]+self.tile_size, segment[1]+self.tile_size, 
                                         fill=color, outline="#222")
            
            # NEW: Draw EYES on the head (segment 0)
            if i == 0:
                eye_size = 4
                # Left eye
                self.canvas.create_oval(segment[0]+4, segment[1]+4, 
                                        segment[0]+4+eye_size, segment[1]+4+eye_size, fill="black")
                # Right eye
                self.canvas.create_oval(segment[0]+12, segment[1]+4, 
                                        segment[0]+12+eye_size, segment[1]+4+eye_size, fill="black")

    def game_over(self):
        self.running = False
        self.canvas.create_text(self.width/2, self.height/2, 
                               text=f"GAME OVER\nFINAL SCORE: {self.score}\nPress R to Restart", 
                               fill="white", font=("Courier", 20, "bold"), justify="center")
        self.root.bind("<r>", lambda e: self.restart())
        self.root.bind("<R>", lambda e: self.restart())

    def restart(self):
        self.root.unbind("<r>")
        self.root.unbind("<R>")
        self.canvas.delete("all")
        self.reset_game()
        self.play()

if __name__ == "__main__":
    root = tk.Tk()
    game = RainbowSnake(root)
    root.mainloop()
