import tkinter as tk
import random
import time

class DragRaceRanked:
    def __init__(self, root):
        self.root = root
        self.root.title("Speed Test: Ranked")
        self.canvas = tk.Canvas(root, width=500, height=400, bg="black")
        self.canvas.pack()
        
        # 1. Draw the Rank Boxes
        self.ranks = []
        rank_data = [("NINJA", "cyan", 0, 199), ("GAMER", "lime", 200, 299), 
                     ("HUMAN", "yellow", 300, 450), ("SLOTH", "red", 451, 9999)]
        
        for i, (name, color, low, high) in enumerate(rank_data):
            box = self.canvas.create_rectangle(380, 50 + (i*80), 480, 120 + (i*80), outline=color, width=2)
            text = self.canvas.create_text(430, 85 + (i*80), text=name, fill="gray")
            self.ranks.append({'box': box, 'text': text, 'color': color, 'low': low, 'high': high})

        # The Racing Light
        self.light = self.canvas.create_oval(120, 100, 220, 200, fill="red")
        self.label = self.canvas.create_text(170, 300, text="Wait for GREEN...", fill="white", font=("Arial", 16))
        
        self.start_time = 0
        self.waiting = False
        self.root.bind("<space>", self.press_pedal)
        self.setup_race()

    def setup_race(self):
        # Reset colors
        for r in self.ranks:
            self.canvas.itemconfig(r['box'], fill="black")
            self.canvas.itemconfig(r['text'], fill="gray")
        
        self.canvas.itemconfig(self.light, fill="red")
        self.canvas.itemconfig(self.label, text="Wait for GREEN...")
        self.root.after(random.randint(2000, 5000), self.go_green)

    def go_green(self):
        self.canvas.itemconfig(self.light, fill="lime")
        self.canvas.itemconfig(self.label, text="GO!")
        self.start_time = time.time()
        self.waiting = True

    def press_pedal(self, event):
        if self.waiting:
            ms = int((time.time() - self.start_time) * 1000)
            self.waiting = False
            self.canvas.itemconfig(self.label, text=f"{ms}ms")
            
            # 2. Highlight the Rank
            for r in self.ranks:
                if r['low'] <= ms <= r['high']:
                    self.canvas.itemconfig(r['box'], fill=r['color'])
                    self.canvas.itemconfig(r['text'], fill="black")
            
            self.root.after(2000, self.setup_race)
        else:
            self.canvas.itemconfig(self.label, text="FALSE START!")
            self.root.after(1000, self.setup_race)

if __name__ == "__main__":
    root = tk.Tk()
    DragRaceRanked(root)
    root.mainloop()
