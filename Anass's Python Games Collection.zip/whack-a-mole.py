import tkinter as tk
import random
import winsound  # Works on Windows for built-in beeps

class WhackAMole:
    def __init__(self, root):
        self.root = root
        self.root.title("Whack-A-Mole! (Sound Edition)")
        
        # 1. Setup Canvas
        self.canvas = tk.Canvas(root, width=600, height=400, bg="#228B22") # Grass Green
        self.canvas.pack()
        
        self.score = 0
        self.time_left = 30
        
        # Hole coordinates (x, y)
        self.holes = [
            (100, 100), (300, 100), (500, 100),
            (100, 300), (300, 300), (500, 300)
        ]
        
        # Draw the holes
        for x, y in self.holes:
            self.canvas.create_oval(x-40, y-20, x+40, y+20, fill="#3e2723") 

        # HUD (Heads Up Display)
        self.score_label = self.canvas.create_text(60, 20, text=f"Score: {self.score}", fill="white", font=("Arial", 16, "bold"))
        self.timer_label = self.canvas.create_text(540, 20, text=f"Time: {self.time_left}", fill="white", font=("Arial", 16, "bold"))

        # Create the Mole (Brown with eyes!)
        self.mole = self.canvas.create_oval(0, 0, 60, 60, fill="#795548", state='hidden')
        self.eye1 = self.canvas.create_oval(0, 0, 8, 8, fill="black", state='hidden')
        self.eye2 = self.canvas.create_oval(0, 0, 8, 8, fill="black", state='hidden')
        
        # Bind clicking to the mole
        self.canvas.tag_bind(self.mole, "<Button-1>", self.whack)
        
        self.is_running = True
        self.move_mole()
        self.countdown()

    def move_mole(self):
        if self.is_running:
            # Pick a random hole
            hole_x, hole_y = random.choice(self.holes)
            
            # Move mole to that hole
            self.canvas.coords(self.mole, hole_x-30, hole_y-50, hole_x+30, hole_y+10)
            self.canvas.coords(self.eye1, hole_x-15, hole_y-35, hole_x-7, hole_y-27)
            self.canvas.coords(self.eye2, hole_x+7, hole_y-35, hole_x+15, hole_y-27)
            
            self.canvas.itemconfig(self.mole, state='normal')
            self.canvas.itemconfig(self.eye1, state='normal')
            self.canvas.itemconfig(self.eye2, state='normal')
            
            # Speed increases as you get more points!
            speed = max(450, 1000 - (self.score * 25))
            self.root.after(speed, self.hide_and_move)

    def hide_and_move(self):
        if self.is_running:
            self.canvas.itemconfig(self.mole, state='hidden')
            self.canvas.itemconfig(self.eye1, state='hidden')
            self.canvas.itemconfig(self.eye2, state='hidden')
            self.root.after(200, self.move_mole)

    def whack(self, event):
        if self.is_running:
            # SOUND: High pitched beep for a hit
            winsound.Beep(1200, 80)
            
            self.score += 1
            self.canvas.itemconfig(self.score_label, text=f"Score: {self.score}")
            self.canvas.itemconfig(self.mole, state='hidden')
            self.canvas.itemconfig(self.eye1, state='hidden')
            self.canvas.itemconfig(self.eye2, state='hidden')

    def countdown(self):
        if self.time_left > 0:
            self.time_left -= 1
            self.canvas.itemconfig(self.timer_label, text=f"Time: {self.time_left}")
            self.root.after(1000, self.countdown)
        else:
            self.game_over()

    def game_over(self):
        self.is_running = False
        # SOUND: Low pitched long beep for Game Over
        winsound.Beep(400, 500)
        
        self.canvas.delete(self.mole, self.eye1, self.eye2)
        self.canvas.create_text(300, 200, text=f"GAME OVER!\nFinal Score: {self.score}", 
                               fill="white", font=("Arial", 32, "bold"), justify="center")

if __name__ == "__main__":
    root = tk.Tk()
    game = WhackAMole(root)
    root.mainloop()
