import random

def play_higher_lower():
    # 1. Define the cards and their values
    # We use a list of tuples: (Name, Value)
    deck = [
        ('2', 2), ('3', 3), ('4', 4), ('5', 5), ('6', 6), ('7', 7), 
        ('8', 8), ('9', 9), ('10', 10), ('Jack', 11), ('Queen', 12), 
        ('King', 13), ('Ace', 14)
    ]
    
    score = 0
    current_card = random.choice(deck)
    
    print("--- WELCOME TO HIGHER OR LOWER ---")
    print("Try to get a high score by guessing the next card!")

    while True:
        print(f"\n[ Current Score: {score} ]")
        print(f"The current card is: {current_card[0]}")
        
        guess = input("Will the next card be HIGHER or LOWER? (h/l): ").lower()
        
        # Get a new card that isn't the same as the current one
        next_card = random.choice(deck)
        while next_card == current_card:
            next_card = random.choice(deck)
            
        print(f"The next card is: {next_card[0]}")

        # 2. Logic to check if the user is right
        if guess == 'h':
            if next_card[1] > current_card[1]:
                print("Correct! It was higher.")
                score += 1
            elif next_card[1] < current_card[1]:
                print("Wrong! It was lower.")
                break
            else:
                print("It's a tie! No points.")
                
        elif guess == 'l':
            if next_card[1] < current_card[1]:
                print("Correct! It was lower.")
                score += 1
            elif next_card[1] > current_card[1]:
                print("Wrong! It was higher.")
                break
            else:
                print("It's a tie! No points.")
        else:
            print("Invalid input! Please type 'h' or 'l'.")
            continue

        # The next card becomes the current card for the next round
        current_card = next_card

    print(f"\nGAME OVER! Your final score was: {score}")

if __name__ == "__main__":
    play_higher_lower()
