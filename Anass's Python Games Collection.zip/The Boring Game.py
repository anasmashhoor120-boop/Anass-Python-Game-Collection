import tkinter as tk
import random

# 1. The List of Fun (You can add your own here!)
activities = [
    "JOKE: Why did the chicken cross the road? To get to the other side!",
    "CHALLENGE: Do 10 jumping jacks right now!",
    "JOKE: What do you call a bear with no teeth? A gummy bear!",
    "CHALLENGE: Spin in a circle 5 times!",
    "JOKE: Why are ghosts bad at lying? Because you can see right through them!",
    "CHALLENGE: Try to touch your toes for 10 seconds!"
]

def play():
    # Pick a random one from the list
    choice = random.choice(activities)
    # Put it on the screen
    label_result.config(text=choice)

# 2. Build the Window
app = tk.Tk()
app.title("The 'I'm Bored' Machine")
app.geometry("500x300")
app.configure(bg="#2c3e50") # Dark blue background

# 3. Add the UI (User Interface)
title = tk.Label(app, text="Bored? Click the Magic Button!", 
                 fg="white", bg="#2c3e50", font=("Arial", 16, "bold"))
title.pack(pady=20)

label_result = tk.Label(app, text="???", fg="#f1c40f", bg="#2c3e50", 
                        font=("Arial", 12), wraplength=400)
label_result.pack(pady=30)

# The Button
btn = tk.Button(app, text="I'M BORED!", command=play, 
                bg="#e74c3c", fg="white", font=("Arial", 14, "bold"),
                padx=20, pady=10)
btn.pack()

app.mainloop()
